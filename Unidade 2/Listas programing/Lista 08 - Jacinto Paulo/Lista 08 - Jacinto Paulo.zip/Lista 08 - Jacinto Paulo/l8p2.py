from thomasjackalg import thomasjackalg
from numpy import loadtxt
from numpy.linalg import solve 

M = loadtxt('MatrixM.txt', float)
t = loadtxt('VetorT.txt', float)


print(M, "\n\n", t)


